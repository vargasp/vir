#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 20 15:41:27 2021

@author: vargasp
"""

import numpy as np
import vir


def siddons(src, trg, nPixels=128, dPixels=1.0,return_array=True):
    """
    An implementation of Siddon's algorithm (Med. Phys., 12, 252-255) for 
    computing the intersection lengths of a line specified by the coordinates
    "source" and "target" with a (X,Y,Z) grid of voxels

    Parameters
    ----------
    src : (3) or (nPostions,3) array_like
        The coordinates of the source position. 
    trg : (3) or (nPostions,3) array_like
        The coordinates of the target position. nPostions must equal source or 
        be equal to one. (Target may have multiple postions and source 1 postiion)
    nPixels : int or (3) array_like
        The number of voxels in the X, Y, and Z dimensions. Default is 512
    dPixels : float or (3) array_like
        The sampling interval in the X, Y, and Z dimensions. Default is 1.0

    Returns
    -------
    (X,Y,Z) numpy ndarray or list of (4) tuples
        If return_array=True returns the 3 dimension array of the average
        intersection length per voxel. If return_array=False returns a list
        of tuples indices and length (X,Y,Z,length) for all intersected voxels        
    """

    #Converts and assigns paramters to approprate data types
    nPixels = np.array(nPixels,dtype=int)
    if nPixels.size == 1:
        nPixels = np.repeat(nPixels,3)
    nX, nY, nZ = nPixels
                 
    dPixels = np.array(dPixels,dtype=float)
    if dPixels.size == 1:
        dPixels = np.repeat(dPixels,3)
    dX, dY, dZ = dPixels

    trg = np.array(trg, dtype=float)
    if trg.ndim == 1:
        trg = trg[np.newaxis,:]

    src = np.array(src, dtype=float)
    if src.ndim == 1:
        src = src[np.newaxis,:]

    #Number of rays     
    nRays = np.shape(trg)[0]

    #Creates the grid of intersecting lines
    X = vir.censpace(nX+1,d=dX)
    Y = vir.censpace(nY+1,d=dY)
    Z = vir.censpace(nZ+1,d=dZ)
    
    p0 = np.array([X[0],Y[0],Z[0]])
    pN = np.array([X[-1],Y[-1],Z[-1]])

    #Calculates deltas between target and source and Euclidean distance 
    dST  = src - trg #(nRays, 3)
    distance = np.linalg.norm(dST, axis=1) #(nRays)

    #Calculate the parametric values of the intersections of the ray with the 
    #first and last grid lines. Assigns 0s to calculations where dividing by 0 
    alpha0 = np.divide(p0-trg, dST, out=np.zeros_like(trg), where=dST!=0)
    alphaN = np.divide(pN-trg, dST, out=np.zeros_like(trg), where=dST!=0)

    #Calculate alpha_min and alpah max, which is either the parametric value of
    #the intersection where the line of interest enters or leaves the grid, or
    #0.0 if the trg is inside the grid.
    m_min = np.zeros([nRays,4])
    m_max = np.ones([nRays,4])
    
    m_min[:,1:][alpha0 < alphaN] = alpha0[alpha0 < alphaN] 
    m_max[:,1:][alpha0 < alphaN] = alphaN[alpha0 < alphaN] 

    m_min[:,1:][alpha0 > alphaN] = alphaN[alpha0 > alphaN] 
    m_max[:,1:][alpha0 > alphaN] = alpha0[alpha0 > alphaN] 

    alpha_min = np.max(m_min, axis=1)
    alpha_max = np.min(m_max, axis=1)
    alpha_bounds = np.vstack([alpha_min,alpha_max]).T

    i0 = np.where(dST > 0.0, np.floor(nPixels+1 - (pN-alpha_min[:,np.newaxis]*dST - trg)/dPixels).astype(int),\
                     np.floor(nPixels+1 - (pN-alpha_max[:,np.newaxis]*dST - trg)/dPixels).astype(int))
    iN = np.where(dST > 0.0, np.ceil((trg+alpha_max[:,np.newaxis]*dST - p0)/dPixels).astype(int),\
                     np.ceil((trg + alpha_min[:,np.newaxis]*dST - p0)/dPixels).astype(int))

    #Loops through the rays intersecting the source and target
    inter_list = []
    for ray in range(nRays):
        #If alpha_max <= alpha_min, then the ray doesn't pass through the grid.
        if alpha_bounds[ray,1] > alpha_bounds[ray,0]:

            #Compute the alpha values of the intersections of the line with all
            #the relevant planes in the grid.
            X_alpha = (X[i0[ray,0]:iN[ray,0]] - trg[ray,0])/dST[ray,0]
            Y_alpha = (Y[i0[ray,1]:iN[ray,1]] - trg[ray,1])/dST[ray,1]
            Z_alpha = (Z[i0[ray,2]:iN[ray,2]] - trg[ray,2])/dST[ray,2]
                        
            #Merges and sorts alphas
            Alpha = np.sort(np.concatenate([alpha_bounds[ray,:], X_alpha, Y_alpha, Z_alpha]), kind='mergesort')

            #Loops through the alphas and calculates pixel length and pixel index
            dAlpha = Alpha[1:] - Alpha[:-1]
            mAlpha = 0.5 * (Alpha[1:] + Alpha[:-1])
            
            x_ind = ((trg[ray,0] + mAlpha*dST[ray,0] - X[0])/dX).astype(int)
            y_ind = ((trg[ray,1] + mAlpha*dST[ray,1] - Y[0])/dY).astype(int)
            z_ind = ((trg[ray,2] + mAlpha*dST[ray,2] - Z[0])/dZ).astype(int)
            
            length = distance[ray]*dAlpha
            
            inter_list.extend(list(zip(x_ind,y_ind,z_ind,length)))
    
    #Returns results as a list for space efficiency or in an array for
    #numerical operation efficiency
    if return_array:
        return siddons_list2array(inter_list, nPixels)
    else:
        return inter_list


#Converts list to an array
def siddons_list2array(inter_list, nPixels):
    iter_array = np.zeros(nPixels)
    cnt_array = np.zeros(nPixels)
    
    for elem in inter_list:
        iter_array[elem[0],elem[1],elem[2]] += elem[3]
        cnt_array[elem[0],elem[1],elem[2]] += 1.0

    iter_array[cnt_array > 0] /= cnt_array[cnt_array > 0]
    
    return iter_array
