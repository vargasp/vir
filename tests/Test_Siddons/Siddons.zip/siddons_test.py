#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 23 22:16:09 2021

@author: vargasp
"""
import numpy as np
import matplotlib.pyplot as plt
import time


import vir
import siddons as sd

nPix = 128
dPix = .5
pixels = vir.censpace(nPix,d=dPix)

trg_x = np.repeat(nPix/2,nPix**2)
trg_y = np.tile(pixels,nPix)
trg_z = np.repeat(pixels,nPix)

trg = list(zip(trg_x,trg_y,trg_z))

src = [-nPix/2,0,0]

start = time.time()
k = sd.siddons(src, trg, nPix, dPix, return_array=True)
end = time.time()
print(end - start)
plt.imshow(k[:,int(nPix/2),:])



